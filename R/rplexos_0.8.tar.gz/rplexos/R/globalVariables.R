globalVariables(c("name", "complement_name", "collection_id",
  "position", "scenario", "phase_id", "period_id", "nrel_time",
  "key", "value"))
