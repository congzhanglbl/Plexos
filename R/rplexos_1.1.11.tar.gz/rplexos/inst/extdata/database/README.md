This file included to prevent R from deleting this folder.
