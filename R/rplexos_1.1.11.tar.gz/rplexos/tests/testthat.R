library(testthat)
library(rplexos)

test_check("rplexos")
